pub fn invert_bool(value: bool) -> bool
{
    return !value;
}